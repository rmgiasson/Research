REVISED BASAL GANGLIA ANALYSIS

Setup
Five groups: HCP healthy controls from synthseg_HCP.csv; UF diagnosis codes 1-4
from T1_synthseg_vols_robust_no_parc.csv joined to column B (diagnosis) of
dbs_master.csv. Codes are retained without assigning disease names.
Each group has separate direct-left, direct-right, indirect-left, and
indirect-right models: 20 configurations total.

Features and preprocessing
Direct: striatum, pallidum, thalamus. Indirect: these plus ventral DC.
No cortex features. Striatum = original caudate + original putamen volume,
summed within hemisphere before ICV normalization or standardization.
Regional volumes are divided by the participant's total intracranial volume.
The single-fit StandardScaler is fitted separately within each configuration.
Each bootstrap resamples N participants with replacement and fits its OWN
StandardScaler on that resample before fitting DirectLiNGAM. There is no
reuse of full-cohort scaling parameters in bootstrap fits. Summing volumes
and dividing by ICV are participant-wise fixed operations, so these are
precomputed before indexing resampled rows; this is algebraically identical
to recomputing them after resampling.

Samples and exclusions
Usable counts: HCP 928; diagnosis 1: 223; diagnosis 2: 82;
diagnosis 3: 21; diagnosis 4: 11. Counts are the same for both hemispheres
and both pathways. One diagnosis-1 participant with zero left-pallidum volume
was excluded from BOTH hemispheres, as requested. All remaining required
volumes are finite and positive. Fifteen MRI records without a matching
diagnosis and 33 diagnosis records without MRI are not analyzed.
Groups 3 and 4 were explicitly approved for exploratory analysis despite
their small sizes. The n<30 flag is a descriptive screening flag, not a
validated statistical sufficiency criterion. Small-group findings require
particular caution; bootstrapping does not increase the independent sample.

Fitting and selection
DirectLiNGAM with default algorithm settings and seed 42 for single fits.
For each configuration, 100 bootstrap attempts; resampling RNG seed 42,
model seeds 42 + zero-based replicate index. The same settings apply to all
groups. A directed edge is selected when abs(standardized coefficient) > 0.1.
Opposite directions are counted separately. Frequencies use successful fits
as denominator; failed fits are never silently counted as absent edges.
Check configuration_summary.csv for success counts before interpretation.
Unthresholded coefficients retain the estimator's zeros but have no added
0.1 cutoff. Saved single-fit adjacency matrices are also unthresholded;
single-fit graphs show abs(coefficient) > 1e-8, with edge-weight labels.
Stability graphs display selection frequency >=50%, with percentage labels.
Each fitted graph is a DAG; a bootstrap frequency summary need not be one.

Files
sample_counts.csv: matched/usable/excluded participants and small-sample flags.
diagnosis_join_audit.csv: matched and unmatched IDs, for local audit; contains
participant identifiers and diagnosis codes.
configuration_summary.csv: sample sizes and bootstrap success counts.
all_directed_edge_frequencies.csv: every possible directed pair in all 20
configurations, including zero-frequency pairs, with single-fit coefficients.
run_metadata.json: settings, versions, input hashes, feature lists and orders.

Each group folder (HCP, 1, 2, 3, 4) contains single_fit_summary.png and
bootstrap_summary.png comparing its four configurations.
Each direct_left/direct_right/indirect_left/indirect_right subfolder contains:
- single_fit_adjacency.csv and single_fit_DAG.png: weighted DAG.
- directed_edge_frequencies.csv and selection_frequency_matrix.csv: edge
  counts/frequencies at the 0.1 coefficient cutoff.
- bootstrap_stability.png: frequency-labeled stable-edge summary.
- bootstrap_unthresholded.csv: all coefficients from every replicate.
- bootstrap_unthresholded.npz: coefficients [replicate,source,target], features,
  sampled row indices into model_input.csv, and per-replicate scaler means/scales.
- replicate_status.csv: success/error status for all 100 attempts.
- model_input.csv: participant IDs, original combined volumes and ICV-normalized
  values before standardization; single_fit_standardized_input.csv: exact
  standardized full-sample model input in corresponding row order.
- excluded_participants.csv: exclusions for that configuration.

Matrix convention: ROW SOURCE -> COLUMN TARGET throughout.
These figures describe inferred MRI volume relationships and resampling
stability, not proven biological causal pathways or diagnostic effects.
Comparisons across groups are descriptive, with substantially unequal sample
sizes and different source cohorts. No hypothesis tests or parameter tuning
were performed. Previous pathway outputs and synthetic benchmarks are separate.

Reproduce from workspace root:
.venv-basal-ganglia/Scripts/python.exe basal_ganglia_diagnosis.py --run --include-small-groups --zero-policy both
Without --run, the script performs only the join and sample/feature preflight.
